from datetime import datetime

import pytz
from django.db import models
import jsonfield

from mysite.settings import PARKING_RATE_PER_MIN, PARKING_SPOT_SPOT

Y = 'Y'
N = 'N'
CHOICE = (
    (Y, 'Yes'),
    (N, 'No'),
)


class ParkingModelManager(models.Manager):
    def bulk_create(self, objs, **kwargs):
        if ParkingSpot.objects.count() >= PARKING_SPOT_SPOT:
            return None
        else:
            return super(ParkingModelManager, self).bulk_create(objs, **kwargs)

    def create(self, **obj_data):
        if ParkingSpot.objects.count() >= PARKING_SPOT_SPOT:
            return None
        else:
            return super().create(**obj_data)  # Python 3 syntax!!


class ParkingSpot(models.Model):
    objects = ParkingModelManager()

    spot_no = models.AutoField(primary_key=True)
    is_slot_available = models.CharField(choices=CHOICE, default=Y, max_length=1)
    creation_date = models.DateTimeField("created", auto_now_add=True, help_text="record creation datetime")
    modified_date = models.DateTimeField("modified", auto_now=True, help_text="record last modification datetime")

    class Meta:
        ordering = ["-creation_date"]

    def __str__(self):
        return str(dict(spot_no=self.spot_no, is_slot_available=self.is_slot_available))

    def book_spot(self, customer_name):
        try:
            new_ticket = Ticket()
            new_ticket.customer_name = customer_name
            print(self)
            new_ticket.parkingspot = self
            new_ticket.save()

            self.is_slot_available = N
            self.save()
            return new_ticket.ticketid
        except Exception as e:
            print(f"Exception : {e}")

    def unbook_spot(self):
        try:
            self.is_slot_available = Y
            self.save()
            return True
        except Exception as e:
            print(f"Exception : {e}")
            return False


class Ticket(models.Model):
    ticketid = models.AutoField(primary_key=True)
    customer_name = models.CharField(max_length=100)
    parkingspot = models.ForeignKey(ParkingSpot, null=True, on_delete=models.DO_NOTHING)
    ticket_data = jsonfield.JSONField()
    creation_date = models.DateTimeField("created", auto_now_add=True, help_text="record creation datetime")
    modified_date = models.DateTimeField("modified", auto_now=True, help_text="record last modification datetime")

    class Meta:
        ordering = ["-creation_date"]

    def __str__(self):
        return str(dict(ticketid=self.ticketid, customer_name=self.customer_name, parkingspot=self.parkingspot))

    def calculate_fare(self):
        from_time = datetime.strptime(self.creation_date.__str__().split('+')[0], "%Y-%m-%d %H:%M:%S.%f")
        to_time = datetime.strptime(datetime.utcnow().__str__().split('+')[0], "%Y-%m-%d %H:%M:%S.%f")

        print(from_time)
        print(to_time)

        minutes_parked = (datetime.utcnow() - from_time).total_seconds() // 60
        total_gross_pay = round(minutes_parked * PARKING_RATE_PER_MIN, 2)
        ticket_data = {
            "Ticket_id": self.ticketid,
            "from_time": str(from_time),
            "to_time": str(to_time),
            "Parked_time": f"{minutes_parked} Minutes",
            "Parking_fare": f"$ {total_gross_pay}",
            "Parking_rate": f"$ {PARKING_RATE_PER_MIN} / minute"
        }
        self.ticket_data = ticket_data
        self.save()
        return ticket_data
