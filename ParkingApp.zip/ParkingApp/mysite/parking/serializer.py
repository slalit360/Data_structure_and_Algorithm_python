from .models import ParkingSpot, Ticket
from rest_framework import serializers


class ParkingSlotSerializer(serializers.HyperlinkedModelSerializer):

    class Meta:
        model = ParkingSpot
        fields = '__all__'


class TicketSerializer(serializers.HyperlinkedModelSerializer):

    class Meta:
        model = Ticket
        fields = ('customer_name')
