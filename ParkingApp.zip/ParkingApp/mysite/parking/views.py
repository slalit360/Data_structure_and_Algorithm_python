from django.core.exceptions import ObjectDoesNotExist
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework import status
from parking.models import ParkingSpot, Ticket


@csrf_exempt
def book_parking_spot(request):
    output_json = {}

    if request.method == 'GET':
        list_of_available_slot = []
        for i in ParkingSpot.objects.filter(is_slot_available='Y').values_list('spot_no'):
            list_of_available_slot.append(i[0])
        output_json["status"] = status.HTTP_200_OK
        output_json["Total_spots_available"] = len(list_of_available_slot)
        output_json["spot_ids"] = list_of_available_slot

    elif request.method == 'POST':
        # book slot
        parking_spot = None

        print(request.POST)
        customer_name = request.POST.get('customer_name', '')

        if customer_name:
            print(f"customer_name : {customer_name}")
            parking_spot = ParkingSpot.objects.filter(is_slot_available='Y').last()

            if customer_name and parking_spot:
                print(f"parking spot_no : {parking_spot.spot_no}")
                try:
                    ticketid = parking_spot.book_spot(customer_name)

                    output_json["message"] = f"Ticket ID : {ticketid} booked against spot_id :" \
                                             f" {parking_spot.spot_no} successfully. "
                    output_json["status"] = status.HTTP_201_CREATED
                except Exception as e:
                    output_json["message"] = str(e)
                    output_json["error"] = f"failed to book against spot_id : {parking_spot.spot_no}"
                    output_json["status"] = status.HTTP_500_INTERNAL_SERVER_ERROR
            else:
                output_json["error"] = "No parking slot available to book, please try booking after some time !"
                output_json["status"] = status.HTTP_200_OK

        else:
            print("customer_name missing in post request body")
            output_json["error"] = "customer_name missing in post request body"
            output_json["status"] = status.HTTP_400_BAD_REQUEST

    else:
        output_json["message"] = "request type must be GET or POST"
        output_json["status"] = status.HTTP_400_BAD_REQUEST

    return JsonResponse(output_json)


@csrf_exempt
def exit_parking_spot(request, ticket_id):
    output_json = {}
    print("ticket_id : ", ticket_id)

    if request.method == 'GET':
        output_json["message"] = "request type must be of POST to unreserved booking"
        output_json["status"] = status.HTTP_400_BAD_REQUEST

    elif request.method == 'POST':
        try:
            ticket_obj = Ticket.objects.get(ticketid=ticket_id)

            if ticket_obj.parkingspot.is_slot_available == 'N':

                ticket_data = ticket_obj.calculate_fare()

                if ticket_obj.parkingspot.unbook_spot():
                    output_json["ticket_data"] = ticket_data
                    output_json["status"] = status.HTTP_201_CREATED

            else:
                output_json["ticket_data"] = ticket_obj.ticket_data if ticket_obj.ticket_data else 'ticket not found in records'
                output_json["message"] = "This ticket is already completed/resolved and slot is available now"
                output_json["status"] = status.HTTP_201_CREATED

        except ObjectDoesNotExist as e:
            output_json["message"] = "Invalid Ticket Number / Not found in records"
            output_json["status"] = status.HTTP_400_BAD_REQUEST

    return JsonResponse(output_json)
