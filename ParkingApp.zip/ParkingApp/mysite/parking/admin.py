from django.contrib import admin

# Register your models here.
from parking.models import Ticket, ParkingSpot
admin.site.register(ParkingSpot)
admin.site.register(Ticket)