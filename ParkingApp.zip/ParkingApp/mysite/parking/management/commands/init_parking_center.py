from django.core.management.base import BaseCommand, CommandError

from mysite.settings import PARKING_SPOT_SPOT
from parking.models import ParkingSpot


class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    def add_arguments(self, parser):
        parser.add_argument('--spots', type=str)

    def handle(self, *args, **options):
        try:
            # for i in range(PARKING_SPOT_SPOT):
            #     ParkingSpot().save()
            # no_of_spots = int(options['spots'])
            ParkingSpots = [ParkingSpot().save() for i in range(PARKING_SPOT_SPOT)]
            ParkingSpot.objects.bulk_create(ParkingSpots)
        except Exception as e:
            raise CommandError(f"ParkingSpot not created : {e}")
