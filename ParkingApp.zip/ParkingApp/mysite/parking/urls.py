from django.conf.urls import url
from django.urls import path

from parking.views import book_parking_spot, exit_parking_spot

urlpatterns = [
    # url(r'^parkingspots/$', book_parking_spot),
    # url(r'^parkingspots/(?P<ticket_id>[0-9]+)/exit/$', exit_parking_spot),
    path('parking-spots/', book_parking_spot),
    path('parking-spots/<int:ticket_id>/exit/', exit_parking_spot)
]
