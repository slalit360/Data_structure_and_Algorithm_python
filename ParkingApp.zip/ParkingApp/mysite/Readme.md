steps to execute project:


1.  Install dependencies
    1.1 activate virtual environment if any
    1.2 pip install -r req.txt

2.  Perform migrations
    2.1 python manage.py makemigrations
    2.2 python manage.py migrate

3.  Create super user
    python manage.py createsuperuser

4.  Run server and init_parking_center

    4.1 python manage.py runserver 8080

    4.2 Initialize Parking center and there spots
    (only no of spots configured can be initiated/created) refer :- PARKING_SPOT_SPOT in settings.py
    system will not allow spots creation more than than PARKING_SPOT_SPOT

    python manage.py init_parking_center --spots <no_of_spot>
    e.g.    python manage.py init_parking_center --spots 100

5. Use tool like postman to make request

    5.1 To get list of all available spots

        GET     http://127.0.0.1:8080/parking-spots/

        response e.g.:-
        {
            "status": 200,
            "Total_spots_available": 10,
            "spot_ids": [
                58,
                57,
                56,
                55,
                54,
                53,
                52,
                ...
            ]
        }

    5.2 To book parking spots

        POST    http://127.0.0.1:8080/parking-spots/

        request body (form-data or x-www-form-urlencoded):

                    add key value pair in table :
                    KEY                 VALUE
                    customer_name       <customer name>

        response e.g.:
            {
                "message": "Ticket ID : 5 booked against spot_id : 50 successfully. ",
                "status": 201
            }

    5.3 To exit parking / unbook

        POST    http://127.0.0.1:8080/parking-spots/<ticket_id>/exit/

        response e.g:
        for invalid ticket id :
            {
                "message": "Invalid Ticket Number / Not found in records",
                "status": 400
            }
        for valid ticket id :
        {
            "ticket_data": {
                "Ticket_id": 11,
                "from_time": "2020-12-14 11:36:06.850858",
                "to_time": "2020-12-14 11:50:15.932910",
                "Parked_time": "14.0 Minutes",
                "Parking_fare": "$ 1.4",
                "Parking_rate": "$ 0.1 / minute"
            },
            "status": 201
        }
        for : if ticket is already closed or to un-book
        {
            "ticket_data": {
                "Ticket_id": 11,
                "from_time": "2020-12-14 11:36:06.850858",
                "to_time": "2020-12-14 11:50:15.932910",
                "Parked_time": "14.0 Minutes",
                "Parking_fare": "$ 1.4",
                "Parking_rate": "$ 0.1 / minute"
            },
            "message": "This ticket is already completed/resolved and slot is available now",
            "status": 201
        }