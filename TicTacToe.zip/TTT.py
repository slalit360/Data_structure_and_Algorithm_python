# Title: Design a command line based TIC TAC TOE game.

class TicTacToe:
    EMPTY = ''
    X = 'X'
    O = 'O'
    TTT_board = {}

    def __init__(self, size=3):
        self.size = size
        for i in range(size):
            for j in range(size):
                self.TTT_board[str(i) + str(j)] = self.EMPTY

    def drawBoard(self):
        print('\n' + '-' * 2 * len(self.TTT_board))
        for key in sorted(self.TTT_board.keys()):
            x, y = key
            if y == '0' and x != '0':
                print('\n' + '-' * 2 * len(self.TTT_board))

            val = self.TTT_board[key]
            if val is not self.EMPTY:
                print(f" {' ' + str(val)} ", sep="|", end="|")
            else:
                print(f" {key} ", sep="|", end="|")
        print('\n' + '-' * 2 * len(self.TTT_board))

    def check_player_won(self, player):

        for n in range(self.size):

            rows = [self.TTT_board[str(i) + str(j)] for i, j in sorted(self.TTT_board.keys()) if n is int(i)]
            cols = [self.TTT_board[str(i) + str(j)] for i, j in sorted(self.TTT_board.keys()) if n is int(j)]
            diag = [self.TTT_board[str(i) + str(j)] for i, j in sorted(self.TTT_board.keys()) if int(i) is int(j)]

            if rows.count(player) is self.size or cols.count(player) is self.size or diag.count(player) is self.size:
                return True

        return False

    def is_board_full(self):
        return list(self.TTT_board.values()).count(self.EMPTY) == 0

    def checkVictory(self):
        return self.is_board_full() or \
               self.check_player_won(self.X) or \
               self.check_player_won(self.O)

    def game_winner(self):
        if self.check_player_won(self.X):
            return self.X
        elif self.check_player_won(self.O):
            return self.O
        elif self.is_board_full():
            return None

    def playerTurn(self, key, player):
        if key in self.TTT_board.keys() and self.TTT_board[key] is self.EMPTY:
            self.TTT_board[key] = player
            return True
        else:
            return False

    def is_move_valid(self, key):
        # matches =  # re.match(r"[0-9]+\s*,\s*[0-9]+", key)
        if key.strip() in self.TTT_board.keys():
            return key.strip()  # tuple(map(int, key.split(',')))
        else:
            return False

    def runGame(self):
        turn = self.O
        # no_of_turns = 0
        while not self.checkVictory():
            input_key = input("Player " + turn + ", place your key: ")
            valid_key = self.is_move_valid(input_key)

            if valid_key and self.playerTurn(valid_key, turn):
                self.drawBoard()
                turn = self.X if turn is self.O else self.O
                # no_of_turns += 1
            else:
                print("Invalid move.")

        winner_player = self.game_winner()
        if winner_player is not None:
            print(f'Congratulations ! Player {winner_player} won !')
        else:
            print('No one won, Seems to be tie')


if __name__ == '__main__':
    ttt = TicTacToe()
    ttt.drawBoard()
    ttt.runGame()